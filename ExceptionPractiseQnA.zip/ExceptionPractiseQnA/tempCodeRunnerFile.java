package ExceptionPractiseQnA;
import java.util.HashMap;

class Bank{
    private HashMap<String, BankAccount> accounts = new HashMap<>();
}